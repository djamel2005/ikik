<footer class="main-footer">
	<div class="footer-left">
		<?php echo e(__('Copyright')); ?> &copy; <?php echo e(date('Y')); ?> <div class="bullet"></div> <?php echo e(__('Developed By')); ?> <a href="#"><?php echo e(config('app.name')); ?></a>
	</div>
	<div class="footer-right">
		<?php echo e(__('1.0.0')); ?>

	</div>
</footer><?php /**PATH C:\xampp\htdocs\newtong\script\resources\views/layouts/backend/partials/footer.blade.php ENDPATH**/ ?>