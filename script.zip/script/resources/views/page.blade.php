@extends('layouts.frontend.app')

@section('content')
<div class="main-area pt-50">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="page-desctiption">
					<p>{{ $page->description }}</p>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection