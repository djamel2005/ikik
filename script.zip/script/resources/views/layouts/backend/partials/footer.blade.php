<footer class="main-footer">
	<div class="footer-left">
		{{ __('Copyright') }} &copy; {{ date('Y') }} <div class="bullet"></div> {{ __('Developed By') }} <a href="#">{{ config('app.name') }}</a>
	</div>
	<div class="footer-right">
		{{ __('1.0.0') }}
	</div>
</footer>